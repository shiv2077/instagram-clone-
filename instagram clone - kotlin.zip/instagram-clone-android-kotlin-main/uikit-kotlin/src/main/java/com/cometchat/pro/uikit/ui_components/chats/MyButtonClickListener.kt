package com.cometchat.pro.uikit.ui_components.chats

interface MyButtonClickListener {
    fun onClick(pos:Int)
}