package com.cometchat.pro.uikit.ui_components.shared.cometchatStickers.listener

import com.cometchat.pro.uikit.ui_components.shared.cometchatStickers.model.Sticker

interface StickerClickListener {
    fun onClickListener(sticker: Sticker?)
}