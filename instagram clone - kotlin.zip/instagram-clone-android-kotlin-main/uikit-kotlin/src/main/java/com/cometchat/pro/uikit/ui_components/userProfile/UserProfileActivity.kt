package com.cometchat.pro.uikit.ui_components.userProfile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cometchat.pro.uikit.R

class UserProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile_actiivty)
    }
}