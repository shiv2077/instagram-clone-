package com.example.instagramclone.model

class Notification {
    var id: String? = null
    var notificationImage: String? = null
    var notificationMessage: String? = null
    var receiverId: String? = null
}